#pragma once

void Quaternion2Euler(
	double* roll,
	double* pitch,
	double* yaw,
	const double q[4]);